# O que está neste ZIP

EXTRAS PRESERVADOS: escolha somente o que usar. Variantes atualizadas estão no ZIP SOMENTE_MAPAS. Painel: 2 folhas por jogador. Peões: 8 folhas. Fichas completas: 12. Guia: 3. Bases: 1. Não imprimir tudo como se fosse obrigatório. Mesmos IDs e limite de 24 inimigos.

| Arquivo | Uso | Folhas | Cópias | Orientação | Impressão | Substitui |
|---|---|---:|---:|---|---|---|
| [08_EXTRAS_OPCIONAIS/FICHAS_24_HEROIS.pdf](../08_EXTRAS_OPCIONAIS/FICHAS_24_HEROIS.pdf) | opcional | 12 | 1 | retrato | uma face | fichas compactas selecionadas, se desejado |
| [04_PERSONAGENS_E_INIMIGOS/HEROIS_24_RECORTAR.pdf](../04_PERSONAGENS_E_INIMIGOS/HEROIS_24_RECORTAR.pdf) | opcional | 2 | 1 | retrato | uma face | marcadores planos, mesmos IDs |
| [04_PERSONAGENS_E_INIMIGOS/INIMIGOS_VARIANTES_E01_E24_RECORTAR.pdf](../04_PERSONAGENS_E_INIMIGOS/INIMIGOS_VARIANTES_E01_E24_RECORTAR.pdf) | opcional | 6 | 1 | retrato | uma face | marcadores planos, mesmos IDs |
| [05_PAINEIS/PAINEL_JOGADOR_2_A4.pdf](../05_PAINEIS/PAINEL_JOGADOR_2_A4.pdf) | opcional | 4 | 2 | paisagem | uma face | organização compacta; mesmas quatro cargas |
| [08_EXTRAS_OPCIONAIS/GUIA_ILUSTRADO_MONTAGEM.pdf](../08_EXTRAS_OPCIONAIS/GUIA_ILUSTRADO_MONTAGEM.pdf) | opcional | 3 | 1 | retrato | uma face | mesmo componente anterior |
| [08_EXTRAS_OPCIONAIS/BASES_ORGANIZACAO.pdf](../08_EXTRAS_OPCIONAIS/BASES_ORGANIZACAO.pdf) | opcional | 1 | 1 | retrato | uma face | mesmo componente anterior |
