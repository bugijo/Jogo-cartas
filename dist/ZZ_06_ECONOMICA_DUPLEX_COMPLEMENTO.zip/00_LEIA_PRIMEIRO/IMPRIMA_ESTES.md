# O que está neste ZIP

economica / COMPLEMENTO: 33 folhas A4. Substitui essa etapa do completo; não imprimir ambos. Somente cartas/calibração duplex retrato, borda longa. Mapas uma face paisagem, 100%.

| Arquivo | Uso | Folhas | Cópias | Orientação | Impressão | Substitui |
|---|---|---:|---:|---|---|---|
| [05_PAINEIS/FICHAS_RESGATAVEIS.pdf](../05_PAINEIS/FICHAS_RESGATAVEIS.pdf) | básico | 6 | 1 | retrato | uma face | mesmo componente anterior |
| [01_GUIA_E_REGRAS/MANUAL.pdf](../01_GUIA_E_REGRAS/MANUAL.pdf) | básico | 8 | 1 | retrato | uma face | mesmo componente anterior |
| [01_GUIA_E_REGRAS/CAMPANHA.pdf](../01_GUIA_E_REGRAS/CAMPANHA.pdf) | básico | 3 | 1 | retrato | uma face | mesmo componente anterior |
| [06_TABULEIROS/SANTA_AURORA_ROTAS.pdf](../06_TABULEIROS/SANTA_AURORA_ROTAS.pdf) | básico | 1 | 1 | paisagem | uma face | mesmo componente anterior |
| [05_PAINEIS/REGISTRO_ADICIONAL.pdf](../05_PAINEIS/REGISTRO_ADICIONAL.pdf) | básico | 2 | 1 | paisagem | uma face | mesmo componente anterior |
| [07_MARCADORES_E_DIVISORIAS/MARCADORES_RESGATAVEIS.pdf](../07_MARCADORES_E_DIVISORIAS/MARCADORES_RESGATAVEIS.pdf) | básico | 1 | 1 | retrato | uma face | mesmo componente anterior |
| [05_PAINEIS/MORADORES_ADICIONAL.pdf](../05_PAINEIS/MORADORES_ADICIONAL.pdf) | básico | 1 | 1 | paisagem | uma face | mesmo componente anterior |
| [02_CARTAS_DUPLEX/KIT_COMPLEMENTO_2_DUPLEX.pdf](../02_CARTAS_DUPLEX/KIT_COMPLEMENTO_2_DUPLEX.pdf) | básico | 6 | 1 | retrato | duplex, borda longa | mesmo componente anterior |
| [06_TABULEIROS/DEMAIS_DESTINOS_MONTAGENS.pdf](../06_TABULEIROS/DEMAIS_DESTINOS_MONTAGENS.pdf) | básico / consulta | 5 | 1 | paisagem | uma face | mesmo componente anterior |
