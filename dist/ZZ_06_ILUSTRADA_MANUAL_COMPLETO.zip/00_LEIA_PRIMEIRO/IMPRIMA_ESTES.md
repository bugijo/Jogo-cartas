# O que está neste ZIP

KIT COMPLETO ilustrada / manual: 72 folhas A4. 33 iniciais + 39 complemento. Tudo uma face. Cole frente + miolo opaco + verso com topos iguais; elimine códigos fora do corte. Cartas e demais componentes preservados da 0.5; mapas atualizados. Escolha só este método, não imprima a outra alternativa.

| Arquivo | Uso | Folhas | Cópias | Orientação | Impressão | Substitui |
|---|---|---:|---:|---|---|---|
| [01_GUIA_E_REGRAS/COMECE_AQUI.pdf](../01_GUIA_E_REGRAS/COMECE_AQUI.pdf) | básico | 6 | 1 | retrato | uma face | mesmo componente anterior |
| [05_PAINEIS/FICHAS_LIA_IVO.pdf](../05_PAINEIS/FICHAS_LIA_IVO.pdf) | básico | 1 | 1 | retrato | uma face | mesmo componente anterior |
| [05_PAINEIS/ABRIGO_MORADORES_ESTOQUE.pdf](../05_PAINEIS/ABRIGO_MORADORES_ESTOQUE.pdf) | básico | 3 | 1 | paisagem | uma face | mesmo componente anterior |
| [07_MARCADORES_E_DIVISORIAS/MARCADORES_INICIAIS.pdf](../07_MARCADORES_E_DIVISORIAS/MARCADORES_INICIAIS.pdf) | básico | 1 | 1 | retrato | uma face | mesmo componente anterior |
| [07_MARCADORES_E_DIVISORIAS/DIVISORIAS.pdf](../07_MARCADORES_E_DIVISORIAS/DIVISORIAS.pdf) | básico | 1 | 1 | retrato | uma face | mesmo componente anterior |
| [05_PAINEIS/FICHAS_RESGATAVEIS.pdf](../05_PAINEIS/FICHAS_RESGATAVEIS.pdf) | básico | 6 | 1 | retrato | uma face | mesmo componente anterior |
| [01_GUIA_E_REGRAS/MANUAL.pdf](../01_GUIA_E_REGRAS/MANUAL.pdf) | básico | 8 | 1 | retrato | uma face | mesmo componente anterior |
| [01_GUIA_E_REGRAS/CAMPANHA.pdf](../01_GUIA_E_REGRAS/CAMPANHA.pdf) | básico | 3 | 1 | retrato | uma face | mesmo componente anterior |
| [06_TABULEIROS/SANTA_AURORA_ROTAS.pdf](../06_TABULEIROS/SANTA_AURORA_ROTAS.pdf) | básico | 1 | 1 | paisagem | uma face | mesmo componente anterior |
| [05_PAINEIS/REGISTRO_ADICIONAL.pdf](../05_PAINEIS/REGISTRO_ADICIONAL.pdf) | básico | 2 | 1 | paisagem | uma face | mesmo componente anterior |
| [07_MARCADORES_E_DIVISORIAS/MARCADORES_RESGATAVEIS.pdf](../07_MARCADORES_E_DIVISORIAS/MARCADORES_RESGATAVEIS.pdf) | básico | 1 | 1 | retrato | uma face | mesmo componente anterior |
| [05_PAINEIS/MORADORES_ADICIONAL.pdf](../05_PAINEIS/MORADORES_ADICIONAL.pdf) | básico | 1 | 1 | paisagem | uma face | mesmo componente anterior |
| [03_CARTAS_RECORTAR_E_COLAR/KIT_INICIAL_1_FRENTES.pdf](../03_CARTAS_RECORTAR_E_COLAR/KIT_INICIAL_1_FRENTES.pdf) | básico | 7 | 1 | retrato | uma face | mesmo componente anterior |
| [03_CARTAS_RECORTAR_E_COLAR/KIT_INICIAL_1_VERSOS.pdf](../03_CARTAS_RECORTAR_E_COLAR/KIT_INICIAL_1_VERSOS.pdf) | básico | 7 | 1 | retrato | uma face | mesmo componente anterior |
| [03_CARTAS_RECORTAR_E_COLAR/KIT_COMPLEMENTO_2_FRENTES.pdf](../03_CARTAS_RECORTAR_E_COLAR/KIT_COMPLEMENTO_2_FRENTES.pdf) | básico | 6 | 1 | retrato | uma face | mesmo componente anterior |
| [03_CARTAS_RECORTAR_E_COLAR/KIT_COMPLEMENTO_2_VERSOS.pdf](../03_CARTAS_RECORTAR_E_COLAR/KIT_COMPLEMENTO_2_VERSOS.pdf) | básico | 6 | 1 | retrato | uma face | mesmo componente anterior |
| [06_TABULEIROS/COMUNS_M01_M04_LADO_A.pdf](../06_TABULEIROS/COMUNS_M01_M04_LADO_A.pdf) | básico | 4 | 1 | paisagem | uma face | mesmo componente anterior |
| [06_TABULEIROS/MERCADO_MONTAGEM.pdf](../06_TABULEIROS/MERCADO_MONTAGEM.pdf) | básico / consulta | 1 | 1 | paisagem | uma face | mesmo componente anterior |
| [06_TABULEIROS/DEMAIS_DESTINOS_MONTAGENS.pdf](../06_TABULEIROS/DEMAIS_DESTINOS_MONTAGENS.pdf) | básico / consulta | 5 | 1 | paisagem | uma face | mesmo componente anterior |
| [03_CARTAS_RECORTAR_E_COLAR/CALIBRACAO_COLAGEM.pdf](../03_CARTAS_RECORTAR_E_COLAR/CALIBRACAO_COLAGEM.pdf) | básico | 2 | 1 | retrato | uma face | mesmo componente anterior |
