# O que está neste ZIP

ilustrada / INICIAL: 25 folhas A4. Substitui essa etapa do completo; não imprimir ambos. Somente cartas/calibração duplex retrato, borda longa. Mapas uma face paisagem, 100%.

| Arquivo | Uso | Folhas | Cópias | Orientação | Impressão | Substitui |
|---|---|---:|---:|---|---|---|
| [01_GUIA_E_REGRAS/COMECE_AQUI.pdf](../01_GUIA_E_REGRAS/COMECE_AQUI.pdf) | básico | 6 | 1 | retrato | uma face | mesmo componente anterior |
| [05_PAINEIS/FICHAS_LIA_IVO.pdf](../05_PAINEIS/FICHAS_LIA_IVO.pdf) | básico | 1 | 1 | retrato | uma face | mesmo componente anterior |
| [05_PAINEIS/ABRIGO_MORADORES_ESTOQUE.pdf](../05_PAINEIS/ABRIGO_MORADORES_ESTOQUE.pdf) | básico | 3 | 1 | paisagem | uma face | mesmo componente anterior |
| [07_MARCADORES_E_DIVISORIAS/MARCADORES_INICIAIS.pdf](../07_MARCADORES_E_DIVISORIAS/MARCADORES_INICIAIS.pdf) | básico | 1 | 1 | retrato | uma face | mesmo componente anterior |
| [07_MARCADORES_E_DIVISORIAS/DIVISORIAS.pdf](../07_MARCADORES_E_DIVISORIAS/DIVISORIAS.pdf) | básico | 1 | 1 | retrato | uma face | mesmo componente anterior |
| [02_CARTAS_DUPLEX/CALIBRACAO_DUPLEX.pdf](../02_CARTAS_DUPLEX/CALIBRACAO_DUPLEX.pdf) | básico | 1 | 1 | retrato | duplex, borda longa | mesmo componente anterior |
| [02_CARTAS_DUPLEX/KIT_INICIAL_1_DUPLEX.pdf](../02_CARTAS_DUPLEX/KIT_INICIAL_1_DUPLEX.pdf) | básico | 7 | 1 | retrato | duplex, borda longa | mesmo componente anterior |
| [06_TABULEIROS/COMUNS_M01_M04_LADO_A.pdf](../06_TABULEIROS/COMUNS_M01_M04_LADO_A.pdf) | básico | 4 | 1 | paisagem | uma face | mesmo componente anterior |
| [06_TABULEIROS/MERCADO_MONTAGEM.pdf](../06_TABULEIROS/MERCADO_MONTAGEM.pdf) | básico / consulta | 1 | 1 | paisagem | uma face | mesmo componente anterior |
