# O que está neste ZIP

ATUALIZAÇÃO PARA QUEM JÁ TEM A 0.5: nenhuma carta, painel, peão ou regra precisa ser baixada/reimpressa. Troque somente as quatro folhas do tabuleiro escolhido: COMUNS OU uma variante temática. Seis diagramas novos substituem os antigos; podem ser consultados na tela. Este ZIP oferece 34 páginas A4: 4 comuns + 24 de seis variantes + 6 diagramas. NÃO é uma ordem para imprimir 34 folhas. Portas e bloqueios impressos mostram a preparação inicial; depois prevalecem marcadores e registro. Tudo uma face, paisagem. Corte 277×190 mm; M1/M2 acima, M3/M4 abaixo, sem girar nem sobrepor.

| Arquivo | Uso | Folhas | Cópias | Orientação | Impressão | Substitui |
|---|---|---:|---:|---|---|---|
| [06_TABULEIROS/COMUNS_M01_M04_LADO_A.pdf](../06_TABULEIROS/COMUNS_M01_M04_LADO_A.pdf) | básico | 4 | 1 | paisagem | uma face | mesmo componente anterior |
| [06_TABULEIROS/MERCADO_MONTAGEM.pdf](../06_TABULEIROS/MERCADO_MONTAGEM.pdf) | básico / consulta | 1 | 1 | paisagem | uma face | mesmo componente anterior |
| [06_TABULEIROS/DEMAIS_DESTINOS_MONTAGENS.pdf](../06_TABULEIROS/DEMAIS_DESTINOS_MONTAGENS.pdf) | básico / consulta | 5 | 1 | paisagem | uma face | mesmo componente anterior |
| [08_EXTRAS_OPCIONAIS/MERCADO_M01_M04_LADO_A.pdf](../08_EXTRAS_OPCIONAIS/MERCADO_M01_M04_LADO_A.pdf) | opcional | 4 | 1 | paisagem | uma face | COMUNS_M01_M04_LADO_A.pdf (quatro folhas) |
| [08_EXTRAS_OPCIONAIS/HOSPITAL_M01_M04_LADO_A.pdf](../08_EXTRAS_OPCIONAIS/HOSPITAL_M01_M04_LADO_A.pdf) | opcional | 4 | 1 | paisagem | uma face | COMUNS_M01_M04_LADO_A.pdf (quatro folhas) |
| [08_EXTRAS_OPCIONAIS/OFICINA_M01_M04_LADO_A.pdf](../08_EXTRAS_OPCIONAIS/OFICINA_M01_M04_LADO_A.pdf) | opcional | 4 | 1 | paisagem | uma face | COMUNS_M01_M04_LADO_A.pdf (quatro folhas) |
| [08_EXTRAS_OPCIONAIS/POSTO_M01_M04_LADO_A.pdf](../08_EXTRAS_OPCIONAIS/POSTO_M01_M04_LADO_A.pdf) | opcional | 4 | 1 | paisagem | uma face | COMUNS_M01_M04_LADO_A.pdf (quatro folhas) |
| [08_EXTRAS_OPCIONAIS/CONDOMINIO_M01_M04_LADO_A.pdf](../08_EXTRAS_OPCIONAIS/CONDOMINIO_M01_M04_LADO_A.pdf) | opcional | 4 | 1 | paisagem | uma face | COMUNS_M01_M04_LADO_A.pdf (quatro folhas) |
| [08_EXTRAS_OPCIONAIS/ESTACAO_M01_M04_LADO_A.pdf](../08_EXTRAS_OPCIONAIS/ESTACAO_M01_M04_LADO_A.pdf) | opcional | 4 | 1 | paisagem | uma face | COMUNS_M01_M04_LADO_A.pdf (quatro folhas) |
